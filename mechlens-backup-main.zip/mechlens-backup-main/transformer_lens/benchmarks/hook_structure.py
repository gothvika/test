"""Hook structure validation benchmarks.

This module provides structure-only validation of hooks. It checks hook existence,
registration, firing, and shape compatibility without comparing activation values.
"""

from typing import Dict, Optional

import torch

from transformer_lens import HookedTransformer
from transformer_lens.benchmarks.utils import (
    BenchmarkResult,
    BenchmarkSeverity,
    make_capture_hook,
    make_grad_capture_hook,
)
from transformer_lens.hook_points import HookPoint
from transformer_lens.model_bridge import TransformerBridge


def benchmark_forward_hooks_structure(
    bridge: TransformerBridge,
    test_text: str,
    reference_model: Optional[HookedTransformer] = None,
    prepend_bos: Optional[bool] = None,
) -> BenchmarkResult:
    """Benchmark forward hooks for structural correctness (existence, firing, shapes).

    This checks:
    - All reference hooks exist in bridge
    - Hooks can be registered
    - Hooks fire during forward pass
    - Hook tensor shapes are compatible

    Args:
        bridge: TransformerBridge model to test
        test_text: Input text for testing
        reference_model: Optional HookedTransformer for comparison
        prepend_bos: Whether to prepend BOS token. If None, uses model default.

    Returns:
        BenchmarkResult with structural validation details
    """
    try:
        bridge_activations: Dict[str, torch.Tensor] = {}
        reference_activations: Dict[str, torch.Tensor] = {}

        # Get all hook names
        if reference_model is not None:
            hook_names = list(reference_model.hook_dict.keys())
        else:
            hook_names = list(bridge.hook_dict.keys())

        # Register hooks on bridge and track missing hooks
        bridge_hook_points: list[tuple[str, HookPoint]] = []
        missing_from_bridge = []
        for hook_name in hook_names:
            if hook_name in bridge.hook_dict:
                hook_point = bridge.hook_dict[hook_name]
                hook_point.add_hook(make_capture_hook(bridge_activations, hook_name))
                bridge_hook_points.append((hook_name, hook_point))
            else:
                missing_from_bridge.append(hook_name)

        # Run bridge forward pass
        with torch.no_grad():
            if prepend_bos is not None:
                _ = bridge(test_text, prepend_bos=prepend_bos)
            else:
                _ = bridge(test_text)

        # Clean up bridge hooks
        for _, hook_point in bridge_hook_points:
            hook_point.remove_hooks()

        # Check for hooks that didn't fire
        registered_hooks = {name for name, _ in bridge_hook_points}
        hooks_that_didnt_fire = registered_hooks - set(bridge_activations.keys())

        if reference_model is None:
            # No reference - just verify hooks were captured
            if hooks_that_didnt_fire:
                return BenchmarkResult(
                    name="forward_hooks_structure",
                    severity=BenchmarkSeverity.WARNING,
                    message=f"{len(hooks_that_didnt_fire)}/{len(registered_hooks)} hooks didn't fire",
                    details={
                        "captured": len(bridge_activations),
                        "registered": len(registered_hooks),
                        "didnt_fire": list(hooks_that_didnt_fire)[:10],
                    },
                )

            return BenchmarkResult(
                name="forward_hooks_structure",
                severity=BenchmarkSeverity.INFO,
                message=f"Bridge captured {len(bridge_activations)} forward hook activations",
                details={"activation_count": len(bridge_activations)},
            )

        # Register hooks on reference model
        reference_hook_points: list[HookPoint] = []
        for hook_name in hook_names:
            if hook_name in reference_model.hook_dict:
                hook_point = reference_model.hook_dict[hook_name]
                hook_point.add_hook(make_capture_hook(reference_activations, hook_name))
                reference_hook_points.append(hook_point)

        # Run reference forward pass
        with torch.no_grad():
            if prepend_bos is not None:
                _ = reference_model(test_text, prepend_bos=prepend_bos)
            else:
                _ = reference_model(test_text)

        # Clean up reference hooks
        for hook_point in reference_hook_points:
            hook_point.remove_hooks()

        # CRITICAL CHECK: Bridge must have all hooks that reference has
        if missing_from_bridge:
            return BenchmarkResult(
                name="forward_hooks_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"Bridge MISSING {len(missing_from_bridge)} hooks from reference",
                details={
                    "missing_count": len(missing_from_bridge),
                    "missing_hooks": missing_from_bridge[:20],
                    "total_reference_hooks": len(hook_names),
                },
                passed=False,
            )

        # CRITICAL CHECK: All registered hooks must fire
        if hooks_that_didnt_fire:
            return BenchmarkResult(
                name="forward_hooks_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"{len(hooks_that_didnt_fire)} hooks DIDN'T FIRE during forward pass",
                details={
                    "didnt_fire_count": len(hooks_that_didnt_fire),
                    "didnt_fire_hooks": list(hooks_that_didnt_fire)[:20],
                    "total_registered": len(registered_hooks),
                },
                passed=False,
            )

        # Check shapes
        common_hooks = set(bridge_activations.keys()) & set(reference_activations.keys())
        shape_mismatches = []

        for hook_name in sorted(common_hooks):
            bridge_tensor = bridge_activations[hook_name]
            reference_tensor = reference_activations[hook_name]

            if bridge_tensor.shape != reference_tensor.shape:
                shape_mismatches.append(
                    f"{hook_name}: Shape {bridge_tensor.shape} vs {reference_tensor.shape}"
                )

        if shape_mismatches:
            return BenchmarkResult(
                name="forward_hooks_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"Found {len(shape_mismatches)}/{len(common_hooks)} hooks with shape incompatibilities",
                details={
                    "total_hooks": len(common_hooks),
                    "shape_mismatches": len(shape_mismatches),
                    "sample_mismatches": shape_mismatches[:5],
                },
                passed=False,
            )

        return BenchmarkResult(
            name="forward_hooks_structure",
            severity=BenchmarkSeverity.INFO,
            message=f"All {len(common_hooks)} forward hooks structurally compatible",
            details={"hook_count": len(common_hooks)},
        )

    except Exception as e:
        return BenchmarkResult(
            name="forward_hooks_structure",
            severity=BenchmarkSeverity.ERROR,
            message=f"Forward hooks structure check failed: {str(e)}",
            passed=False,
        )


def benchmark_backward_hooks_structure(
    bridge: TransformerBridge,
    test_text: str,
    reference_model: Optional[HookedTransformer] = None,
    prepend_bos: Optional[bool] = None,
) -> BenchmarkResult:
    """Benchmark backward hooks for structural correctness (existence, firing, shapes).

    This checks:
    - All reference backward hooks exist in bridge
    - Hooks can be registered
    - Hooks fire during backward pass
    - Gradient tensor shapes are compatible

    Args:
        bridge: TransformerBridge model to test
        test_text: Input text for testing
        reference_model: Optional HookedTransformer for comparison
        prepend_bos: Whether to prepend BOS token. If None, uses model default.

    Returns:
        BenchmarkResult with structural validation details
    """
    try:
        bridge_grads: Dict[str, torch.Tensor] = {}
        reference_grads: Dict[str, torch.Tensor] = {}

        # Get all hook names that support gradients
        if reference_model is not None:
            hook_names = list(reference_model.hook_dict.keys())
        else:
            hook_names = list(bridge.hook_dict.keys())

        # Filter to hooks that typically have gradients
        grad_hook_names = [
            name
            for name in hook_names
            if any(
                keyword in name
                for keyword in [
                    "hook_embed",
                    "hook_pos_embed",
                    "hook_resid",
                    "hook_q",
                    "hook_k",
                    "hook_v",
                    "hook_z",
                    "hook_result",
                    "hook_mlp_out",
                    "hook_pre",
                    "hook_post",
                ]
            )
        ]

        # Register backward hooks on bridge
        bridge_hook_points: list[tuple[str, HookPoint]] = []
        missing_from_bridge = []
        for hook_name in grad_hook_names:
            if hook_name in bridge.hook_dict:
                hook_point = bridge.hook_dict[hook_name]
                hook_point.add_hook(make_grad_capture_hook(bridge_grads, hook_name), dir="bwd")
                bridge_hook_points.append((hook_name, hook_point))
            else:
                missing_from_bridge.append(hook_name)

        # Run bridge forward + backward pass
        if prepend_bos is not None:
            logits = bridge(test_text, prepend_bos=prepend_bos)
        else:
            logits = bridge(test_text)

        loss = logits[:, -1, :].sum()
        loss.backward()

        # Clean up bridge hooks
        for _, hook_point in bridge_hook_points:
            hook_point.remove_hooks(dir="bwd")

        # Check for hooks that didn't fire
        registered_hooks = {name for name, _ in bridge_hook_points}
        hooks_that_didnt_fire = registered_hooks - set(bridge_grads.keys())

        if reference_model is None:
            # No reference - just verify gradients were captured
            if hooks_that_didnt_fire:
                return BenchmarkResult(
                    name="backward_hooks_structure",
                    severity=BenchmarkSeverity.WARNING,
                    message=f"{len(hooks_that_didnt_fire)}/{len(registered_hooks)} backward hooks didn't fire",
                    details={
                        "captured": len(bridge_grads),
                        "registered": len(registered_hooks),
                        "didnt_fire": list(hooks_that_didnt_fire)[:10],
                    },
                )

            return BenchmarkResult(
                name="backward_hooks_structure",
                severity=BenchmarkSeverity.INFO,
                message=f"Bridge captured {len(bridge_grads)} backward hook gradients",
                details={"gradient_count": len(bridge_grads)},
            )

        # Register backward hooks on reference
        reference_hook_points: list[HookPoint] = []
        for hook_name in grad_hook_names:
            if hook_name in reference_model.hook_dict:
                hook_point = reference_model.hook_dict[hook_name]
                hook_point.add_hook(make_grad_capture_hook(reference_grads, hook_name), dir="bwd")
                reference_hook_points.append(hook_point)

        # Run reference forward + backward pass
        if prepend_bos is not None:
            ref_logits = reference_model(test_text, prepend_bos=prepend_bos)
        else:
            ref_logits = reference_model(test_text)

        ref_loss = ref_logits[:, -1, :].sum()
        ref_loss.backward()

        # Clean up reference hooks
        for hook_point in reference_hook_points:
            hook_point.remove_hooks(dir="bwd")

        # CRITICAL CHECK: Bridge must have all backward hooks that reference has
        if missing_from_bridge:
            return BenchmarkResult(
                name="backward_hooks_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"Bridge MISSING {len(missing_from_bridge)} backward hooks from reference",
                details={
                    "missing_count": len(missing_from_bridge),
                    "missing_hooks": missing_from_bridge[:20],
                    "total_reference_hooks": len(grad_hook_names),
                },
                passed=False,
            )

        # CRITICAL CHECK: All registered hooks must fire
        if hooks_that_didnt_fire:
            return BenchmarkResult(
                name="backward_hooks_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"{len(hooks_that_didnt_fire)} backward hooks DIDN'T FIRE",
                details={
                    "didnt_fire_count": len(hooks_that_didnt_fire),
                    "didnt_fire_hooks": list(hooks_that_didnt_fire)[:20],
                    "total_registered": len(registered_hooks),
                },
                passed=False,
            )

        # Check gradient shapes
        common_hooks = set(bridge_grads.keys()) & set(reference_grads.keys())
        shape_mismatches = []

        for hook_name in sorted(common_hooks):
            bridge_grad = bridge_grads[hook_name]
            reference_grad = reference_grads[hook_name]

            if bridge_grad.shape != reference_grad.shape:
                shape_mismatches.append(
                    f"{hook_name}: Shape {bridge_grad.shape} vs {reference_grad.shape}"
                )

        if shape_mismatches:
            return BenchmarkResult(
                name="backward_hooks_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"Found {len(shape_mismatches)}/{len(common_hooks)} hooks with gradient shape incompatibilities",
                details={
                    "total_hooks": len(common_hooks),
                    "shape_mismatches": len(shape_mismatches),
                    "sample_mismatches": shape_mismatches[:5],
                },
                passed=False,
            )

        return BenchmarkResult(
            name="backward_hooks_structure",
            severity=BenchmarkSeverity.INFO,
            message=f"All {len(common_hooks)} backward hooks structurally compatible",
            details={"hook_count": len(common_hooks)},
        )

    except Exception as e:
        return BenchmarkResult(
            name="backward_hooks_structure",
            severity=BenchmarkSeverity.ERROR,
            message=f"Backward hooks structure check failed: {str(e)}",
            passed=False,
        )


def benchmark_activation_cache_structure(
    bridge: TransformerBridge,
    test_text: str,
    reference_model: Optional[HookedTransformer] = None,
    prepend_bos: Optional[bool] = None,
) -> BenchmarkResult:
    """Benchmark activation cache for structural correctness (keys, shapes).

    This checks:
    - Cache returns expected keys
    - Cache tensor shapes are compatible
    - run_with_cache works correctly

    Args:
        bridge: TransformerBridge model to test
        test_text: Input text for testing
        reference_model: Optional HookedTransformer for comparison
        prepend_bos: Whether to prepend BOS token. If None, uses model default.

    Returns:
        BenchmarkResult with structural validation details
    """
    try:
        # Run bridge with cache
        if prepend_bos is not None:
            _, bridge_cache = bridge.run_with_cache(test_text, prepend_bos=prepend_bos)
        else:
            _, bridge_cache = bridge.run_with_cache(test_text)

        bridge_keys = set(bridge_cache.keys())

        if reference_model is None:
            # No reference - just verify cache works
            if len(bridge_keys) == 0:
                return BenchmarkResult(
                    name="activation_cache_structure",
                    severity=BenchmarkSeverity.DANGER,
                    message="Cache is empty",
                    passed=False,
                )

            return BenchmarkResult(
                name="activation_cache_structure",
                severity=BenchmarkSeverity.INFO,
                message=f"Cache captured {len(bridge_keys)} activations",
                details={"cache_size": len(bridge_keys)},
            )

        # Run reference with cache
        if prepend_bos is not None:
            _, ref_cache = reference_model.run_with_cache(test_text, prepend_bos=prepend_bos)
        else:
            _, ref_cache = reference_model.run_with_cache(test_text)

        ref_keys = set(ref_cache.keys())

        # Check for missing keys
        missing_keys = ref_keys - bridge_keys

        if missing_keys:
            return BenchmarkResult(
                name="activation_cache_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"Cache MISSING {len(missing_keys)} keys from reference",
                details={
                    "missing_count": len(missing_keys),
                    "missing_keys": list(missing_keys)[:20],
                    "total_reference_keys": len(ref_keys),
                },
                passed=False,
            )

        # Check shapes of common keys
        common_keys = bridge_keys & ref_keys
        shape_mismatches = []

        for key in sorted(common_keys):
            bridge_tensor = bridge_cache[key]
            ref_tensor = ref_cache[key]

            if bridge_tensor.shape != ref_tensor.shape:
                shape_mismatches.append(f"{key}: Shape {bridge_tensor.shape} vs {ref_tensor.shape}")

        if shape_mismatches:
            return BenchmarkResult(
                name="activation_cache_structure",
                severity=BenchmarkSeverity.DANGER,
                message=f"Found {len(shape_mismatches)}/{len(common_keys)} cache entries with shape incompatibilities",
                details={
                    "total_keys": len(common_keys),
                    "shape_mismatches": len(shape_mismatches),
                    "sample_mismatches": shape_mismatches[:5],
                },
                passed=False,
            )

        return BenchmarkResult(
            name="activation_cache_structure",
            severity=BenchmarkSeverity.INFO,
            message=f"All {len(common_keys)} cache entries structurally compatible",
            details={"cache_size": len(common_keys)},
        )

    except Exception as e:
        import traceback

        return BenchmarkResult(
            name="activation_cache_structure",
            severity=BenchmarkSeverity.ERROR,
            message=f"Activation cache structure check failed: {str(e)}",
            details={
                "error_type": type(e).__name__,
                "error_message": str(e),
                "traceback": traceback.format_exc(),
            },
            passed=False,
        )
