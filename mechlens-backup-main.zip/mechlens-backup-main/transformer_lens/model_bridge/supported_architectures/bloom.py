"""Bloom architecture adapter."""

from typing import Any

import torch

from transformer_lens.conversion_utils.conversion_steps import RearrangeTensorConversion
from transformer_lens.conversion_utils.param_processing_conversion import (
    ParamProcessingConversion,
)
from transformer_lens.model_bridge.architecture_adapter import ArchitectureAdapter
from transformer_lens.model_bridge.generalized_components import (
    BloomAttentionBridge,
    BloomBlockBridge,
    BloomMLPBridge,
    EmbeddingBridge,
    LinearBridge,
    NormalizationBridge,
    UnembeddingBridge,
)


class BloomArchitectureAdapter(ArchitectureAdapter):
    """Architecture adapter for Bloom models."""

    def __init__(self, cfg: Any) -> None:
        """Initialize the Bloom architecture adapter."""
        super().__init__(cfg)

        # Set config variables for weight processing
        self.cfg.normalization_type = "LN"
        self.cfg.positional_embedding_type = "alibi"
        self.cfg.final_rms = False
        self.cfg.gated_mlp = False
        self.cfg.attn_only = False

        self.cfg.default_prepend_bos = False
        # After split_qkv_matrix, Q/K/V are individual [n_heads*d_head, d_model] weights.
        # Convert to TL format [n_heads, d_model, d_head].
        self.weight_processing_conversions = {
            "blocks.{i}.attn.q": ParamProcessingConversion(
                tensor_conversion=RearrangeTensorConversion(
                    "(n h) m -> n m h",
                    n=self.cfg.n_heads,
                ),
            ),
            "blocks.{i}.attn.k": ParamProcessingConversion(
                tensor_conversion=RearrangeTensorConversion(
                    "(n h) m -> n m h",
                    n=self.cfg.n_heads,
                ),
            ),
            "blocks.{i}.attn.v": ParamProcessingConversion(
                tensor_conversion=RearrangeTensorConversion(
                    "(n h) m -> n m h",
                    n=self.cfg.n_heads,
                ),
            ),
            "blocks.{i}.attn.o": ParamProcessingConversion(
                tensor_conversion=RearrangeTensorConversion("m (n h) -> n h m", n=self.cfg.n_heads),
            ),
        }

        self.component_mapping = {
            "embed": EmbeddingBridge(name="transformer.word_embeddings"),
            "embed_ln": NormalizationBridge(
                name="transformer.word_embeddings_layernorm", config=self.cfg
            ),
            "blocks": BloomBlockBridge(
                name="transformer.h",
                config=self.cfg,
                submodules={
                    "ln1": NormalizationBridge(name="input_layernorm", config=self.cfg),
                    "ln2": NormalizationBridge(name="post_attention_layernorm", config=self.cfg),
                    "attn": BloomAttentionBridge(
                        name="self_attention",
                        config=self.cfg,
                        split_qkv_matrix=self.split_qkv_matrix,
                        submodules={
                            "qkv": LinearBridge(name="query_key_value"),
                            "o": LinearBridge(name="dense"),
                        },
                    ),
                    "mlp": BloomMLPBridge(
                        name="mlp",
                        submodules={
                            "in": LinearBridge(name="dense_h_to_4h"),
                            "out": LinearBridge(name="dense_4h_to_h"),
                        },
                    ),
                },
            ),
            "ln_final": NormalizationBridge(name="transformer.ln_f", config=self.cfg),
            "unembed": UnembeddingBridge(name="lm_head"),
        }

    def split_qkv_matrix(
        self, original_attention_component: Any
    ) -> tuple[torch.nn.Linear, torch.nn.Linear, torch.nn.Linear]:
        """Split the QKV matrix into separate linear transformations.
        Args:
            attention_component: The original attention layer component
        Returns:
            Tuple of nn.Linear modules for Q, K, and V transformations
        """

        # Keep mypy happy
        assert original_attention_component is not None
        assert original_attention_component.query_key_value is not None

        qkv_weights = original_attention_component.query_key_value.weight

        # Keep mypy happy
        assert isinstance(qkv_weights, torch.Tensor)

        # Bloom QKV weights are interleaved: [Q0,K0,V0, Q1,K1,V1, ...]
        # i.e. layout is (n_heads, 3, d_head), not (3, n_heads*d_head).
        # Reshape to [d_model, n_heads, 3, d_head] to correctly deinterleave.
        W_split = qkv_weights.T.reshape(self.cfg.d_model, self.cfg.n_heads, 3, self.cfg.d_head)

        # W_Q/K/V shape: [d_model, n_heads, d_head]
        W_Q, W_K, W_V = W_split[..., 0, :], W_split[..., 1, :], W_split[..., 2, :]

        qkv_bias = original_attention_component.query_key_value.bias

        # Keep mypy happy
        assert isinstance(qkv_bias, torch.Tensor)

        # Same interleaved layout for bias: reshape to [n_heads, 3, d_head]
        qkv_bias = qkv_bias.reshape(self.cfg.n_heads, 3, self.cfg.d_head)

        # b_Q/K/V shape: [n_heads, d_head]
        b_Q, b_K, b_V = qkv_bias[:, 0, :], qkv_bias[:, 1, :], qkv_bias[:, 2, :]

        # Create nn.Linear modules
        # W_Q shape is [d_model, n_heads, d_head] -> flatten to [d_model, n_heads*d_head]
        # nn.Linear expects weight shape [out_features, in_features] = [n_heads*d_head, d_model]
        d_out = self.cfg.n_heads * self.cfg.d_head

        W_Q_transformation = torch.nn.Linear(self.cfg.d_model, d_out, bias=True)
        W_Q_transformation.weight = torch.nn.Parameter(W_Q.reshape(self.cfg.d_model, d_out).T)
        W_Q_transformation.bias = torch.nn.Parameter(b_Q.reshape(d_out))

        W_K_transformation = torch.nn.Linear(self.cfg.d_model, d_out, bias=True)
        W_K_transformation.weight = torch.nn.Parameter(W_K.reshape(self.cfg.d_model, d_out).T)
        W_K_transformation.bias = torch.nn.Parameter(b_K.reshape(d_out))

        W_V_transformation = torch.nn.Linear(self.cfg.d_model, d_out, bias=True)
        W_V_transformation.weight = torch.nn.Parameter(W_V.reshape(self.cfg.d_model, d_out).T)
        W_V_transformation.bias = torch.nn.Parameter(b_V.reshape(d_out))

        return W_Q_transformation, W_K_transformation, W_V_transformation
